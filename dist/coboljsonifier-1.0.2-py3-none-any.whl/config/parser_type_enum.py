from enum import Enum

class ParseType(Enum):
    BINARY_EBCDIC = "BINARY_EBCDIC"
    FLAT_ASCII = "FLAT_ASCII"

